package com.marvellous.MarvellousFullStack.Controller;

public class HealthCheck
{

}
