package com.marvellous.MarvellousFullStack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarvellousFullStackApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarvellousFullStackApplication.class, args);
	}

}
